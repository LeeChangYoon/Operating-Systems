#include <pthread.h>
#include <sched.h>
#include <stdio.h>

int main(int argc, char * arg[])
{
	return 0;
}
